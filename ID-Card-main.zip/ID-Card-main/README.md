# ID-Card
branch 1 deer anhnii html bolon css ashiglan hiisen ID card baigaa ba main deer tuuniig lab6 iin hureend oorclon oruulsan 
Main deer bairlah Id card deer method POST iig ashiglasan baih ba ene ni servert utga ogc baigaag iltgene
harin method GET ashiglah ni SERVER deerees utga avch baigaa yavdal um Tiim ucraas ehleed Post hiihgui bol GET ashiglagdahgui bna
